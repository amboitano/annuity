
package business;

import java.util.ArrayList;

/**
 *
 * @author acmor
 */
public class AnnuityMonth {
    private int month;
    private double bbal, deposit, deposit2, intearn, ebal;
    
    public AnnuityMonth() {
        this.month = 0;
        this.bbal = 0;
        this.deposit = 0;
        this.deposit2 = 0;
        this.intearn = 0;
        this.ebal = 0;
    }
    public AnnuityMonth(int m, double bb, double dep, double dep2, double ie, double eb) {
        this.month = m;
        this.bbal = bb;
        this.deposit = dep;
        this.deposit2 = dep2;
        this.intearn = ie;
        this.ebal = eb;
    }

    AnnuityMonth(int i, double d, double deposit, double d0, double d1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public double getBbal() {
        return bbal;
    }

    public void setBbal(double bbal) {
        this.bbal = bbal;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }
    
    public double getDeposit2() {
        return deposit2;
    }
    
    public void setDeposit2(double deposit2) {
        this.deposit2 = deposit2;
    }

    public double getIntearn() {
        return intearn;
    }

    public void setIntearn(double intearn) {
        this.intearn = intearn;
    }

    public double getEbal() {
        return ebal;
    }

    public void setEbal(double ebal) {
        this.ebal = ebal;
    }
  
            
            
    }

